<!-- Begin grey separator -->
<div class="greySeparator"></div>
<!--/ End grey separator -->
<!-- Begin footer -->
<div class="footer"> Copyright &copy; 2011, <? bloginfo('name'); ?>. <?php echo get_option('of_copyright') ?> </div>
<!--/ End footer -->
</div>
<!--/ End container -->
<?php wp_footer(); ?>
</body>
</html>